from boto3_type_annotations.sagemaker_runtime.client import Client
    
__all__ = (
    'Client'
)
