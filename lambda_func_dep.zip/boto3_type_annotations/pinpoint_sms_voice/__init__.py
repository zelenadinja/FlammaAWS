from boto3_type_annotations.pinpoint_sms_voice.client import Client
    
__all__ = (
    'Client'
)
