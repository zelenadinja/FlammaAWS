from boto3_type_annotations.ds.client import Client
    
__all__ = (
    'Client'
)
