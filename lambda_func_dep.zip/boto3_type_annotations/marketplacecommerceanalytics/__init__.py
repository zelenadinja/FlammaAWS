from boto3_type_annotations.marketplacecommerceanalytics.client import Client
    
__all__ = (
    'Client'
)
