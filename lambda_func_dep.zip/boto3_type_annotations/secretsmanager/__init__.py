from boto3_type_annotations.secretsmanager.client import Client
    
__all__ = (
    'Client'
)
