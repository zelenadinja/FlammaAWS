from boto3_type_annotations.elbv2.client import Client
    
__all__ = (
    'Client'
)
