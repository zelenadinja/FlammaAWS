from boto3_type_annotations.servicediscovery.client import Client
    
__all__ = (
    'Client'
)
