from boto3_type_annotations.snowball.client import Client
    
__all__ = (
    'Client'
)
