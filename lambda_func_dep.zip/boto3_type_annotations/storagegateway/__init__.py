from boto3_type_annotations.storagegateway.client import Client
    
__all__ = (
    'Client'
)
