from boto3_type_annotations.emr.client import Client
    
__all__ = (
    'Client'
)
