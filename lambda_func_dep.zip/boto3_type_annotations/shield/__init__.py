from boto3_type_annotations.shield.client import Client
    
__all__ = (
    'Client'
)
