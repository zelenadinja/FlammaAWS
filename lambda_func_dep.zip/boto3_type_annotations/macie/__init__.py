from boto3_type_annotations.macie.client import Client
    
__all__ = (
    'Client'
)
