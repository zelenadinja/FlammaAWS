from boto3_type_annotations.worklink.client import Client
    
__all__ = (
    'Client'
)
