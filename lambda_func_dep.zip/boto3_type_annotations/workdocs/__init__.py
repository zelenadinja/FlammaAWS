from boto3_type_annotations.workdocs.client import Client
    
__all__ = (
    'Client'
)
