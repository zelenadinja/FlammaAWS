from boto3_type_annotations.translate.client import Client
    
__all__ = (
    'Client'
)
