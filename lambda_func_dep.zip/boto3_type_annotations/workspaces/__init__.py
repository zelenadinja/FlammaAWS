from boto3_type_annotations.workspaces.client import Client
    
__all__ = (
    'Client'
)
