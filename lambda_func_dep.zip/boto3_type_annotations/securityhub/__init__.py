from boto3_type_annotations.securityhub.client import Client
    
__all__ = (
    'Client'
)
