from boto3_type_annotations.autoscaling_plans.client import Client
    
__all__ = (
    'Client'
)
