from boto3_type_annotations.route53resolver.client import Client
    
__all__ = (
    'Client'
)
