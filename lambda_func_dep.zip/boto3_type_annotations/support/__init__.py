from boto3_type_annotations.support.client import Client
    
__all__ = (
    'Client'
)
