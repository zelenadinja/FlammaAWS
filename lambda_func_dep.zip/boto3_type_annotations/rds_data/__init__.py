from boto3_type_annotations.rds_data.client import Client
    
__all__ = (
    'Client'
)
