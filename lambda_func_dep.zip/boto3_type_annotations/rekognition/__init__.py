from boto3_type_annotations.rekognition.client import Client
    
__all__ = (
    'Client'
)
