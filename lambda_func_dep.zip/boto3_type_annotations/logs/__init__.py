from boto3_type_annotations.logs.client import Client
    
__all__ = (
    'Client'
)
