from boto3_type_annotations.waf_regional.client import Client
    
__all__ = (
    'Client'
)
