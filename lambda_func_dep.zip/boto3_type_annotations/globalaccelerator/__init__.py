from boto3_type_annotations.globalaccelerator.client import Client
    
__all__ = (
    'Client'
)
