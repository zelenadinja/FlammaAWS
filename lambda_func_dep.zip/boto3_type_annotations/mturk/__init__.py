from boto3_type_annotations.mturk.client import Client
    
__all__ = (
    'Client'
)
