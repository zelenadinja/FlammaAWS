from boto3_type_annotations.sagemaker.client import Client
    
__all__ = (
    'Client'
)
