from boto3_type_annotations.cloudtrail.client import Client
    
__all__ = (
    'Client'
)
