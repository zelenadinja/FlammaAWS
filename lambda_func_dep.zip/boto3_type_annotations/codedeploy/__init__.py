from boto3_type_annotations.codedeploy.client import Client
    
__all__ = (
    'Client'
)
