from boto3_type_annotations.sms.client import Client
    
__all__ = (
    'Client'
)
