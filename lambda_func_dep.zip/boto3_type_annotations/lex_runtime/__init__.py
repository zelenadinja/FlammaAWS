from boto3_type_annotations.lex_runtime.client import Client
    
__all__ = (
    'Client'
)
