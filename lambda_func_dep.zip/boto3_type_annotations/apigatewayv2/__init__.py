from boto3_type_annotations.apigatewayv2.client import Client
    
__all__ = (
    'Client'
)
