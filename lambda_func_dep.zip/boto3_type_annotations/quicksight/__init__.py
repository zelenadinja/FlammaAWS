from boto3_type_annotations.quicksight.client import Client
    
__all__ = (
    'Client'
)
