from boto3_type_annotations.health.client import Client
    
__all__ = (
    'Client'
)
