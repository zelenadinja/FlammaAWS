from boto3_type_annotations.mediastore_data.client import Client
    
__all__ = (
    'Client'
)
