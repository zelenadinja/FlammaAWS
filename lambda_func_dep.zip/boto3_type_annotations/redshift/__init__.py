from boto3_type_annotations.redshift.client import Client
    
__all__ = (
    'Client'
)
